/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ussd;

import hms.kite.samples.api.ussd.MoUssdListener;
import hms.kite.samples.api.ussd.OperationType;
import hms.kite.samples.api.ussd.UssdRequestSender;
import hms.kite.samples.api.ussd.messages.MoUssdReq;
import hms.kite.samples.api.ussd.messages.MtUssdReq;
import java.net.URL;

/**
 *
 * @author Kasun Edward
 */
public class UssdListener implements MoUssdListener{

    @Override
    public void init() {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
    
    
    }

    @Override
    public void onReceivedUssd(MoUssdReq moUssdReq) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    
     MtUssdReq mtUssdReq=new MtUssdReq();
        mtUssdReq.setApplicationId("APP_000001");
        mtUssdReq.setPassword("password");
        mtUssdReq.setDestinationAddress(moUssdReq.getSourceAddress());
        mtUssdReq.setMessage("Welcome to Lagna USSD");
        mtUssdReq.setSessionId(moUssdReq.getSessionId());
        mtUssdReq.setUssdOperation(OperationType.MT_CONT.getName());

        try{
            UssdRequestSender ussdRequestSender=new UssdRequestSender(new URL("127.0.0.1:7000/ussd/send"));
            ussdRequestSender.sendUssdRequest(mtUssdReq);
        }catch(Exception e){
            e.printStackTrace();
        }
    
    
    }
    
}
